import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Heart, Smartphone, Calendar, Shield } from "lucide-react"
import Image from "next/image"

export function HealthCardFeature() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-background to-accent/5">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full">
              <Heart className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">Novidade PatoolaFam</span>
            </div>

            <h2 className="text-4xl md:text-5xl font-bold text-balance leading-tight">
              Cartão de Saúde do seu Pet sempre à mão
            </h2>

            <p className="text-lg text-muted-foreground text-pretty">
              Tenha todo o histórico de saúde do seu bichinho no celular, organizado e acessível a qualquer momento.
              Vacinas, consultas, peso, alimentação e muito mais — tudo em um só lugar.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 py-4">
              <div className="flex gap-3">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                    <Smartphone className="h-5 w-5 text-accent" />
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Sempre Disponível</h3>
                  <p className="text-sm text-muted-foreground">Acesse de qualquer lugar, a qualquer hora</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-accent" />
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Histórico Completo</h3>
                  <p className="text-sm text-muted-foreground">Registre cada momento de cuidado</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                    <Shield className="h-5 w-5 text-accent" />
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Seguro e Privado</h3>
                  <p className="text-sm text-muted-foreground">Seus dados salvos localmente</p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                    <Heart className="h-5 w-5 text-accent" />
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Feito com Amor</h3>
                  <p className="text-sm text-muted-foreground">Pensado para tutores dedicados</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button asChild size="lg" className="gap-2 text-lg px-8">
                <Link href="/carteira-vacina">Ver Cartão de Saúde</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="gap-2 text-lg px-8 bg-transparent">
                <a href="#sobre">Saiba Mais</a>
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-8 border-background">
              <div className="aspect-[9/16] bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center">
                <Image
                  src="/maltese-dog-vaccine-card-patoolafam.jpg"
                  alt="Cachorro Maltês segurando cartão de vacina PatoolaFam"
                  width={450}
                  height={800}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-primary rounded-full opacity-20 blur-2xl" />
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-accent rounded-full opacity-20 blur-2xl" />
          </div>
        </div>
      </div>
    </section>
  )
}
